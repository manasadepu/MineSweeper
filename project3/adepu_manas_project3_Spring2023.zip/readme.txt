Name: Manas Adepu
Section: 10859
UFL email: manasadepu@ufl.edu
System: UNIX macOS
Compiler: GCC
IDE: Clion
Other notes: My CPU is not M1